


							FILE MANAGER

				A Mini-Project by Sai Suman Chitturi and Praneeth Kapila

				PLEASE READ THE FOLLOWING STATEMENTS BEFORE USING THE APPLICATION


	1. The Complete Application is designed using the C Language and it works only in Linux based Operating Systems.

	2. The Files "Introduction.txt" and "Conclusion.txt" shall be in the same folder where the Application is Present

	3. This application is not responsible for any loss or damage of files (especially regarding Copy, Move and Delete Operations).

	4. Since this is designed using the C Language, we are sorry for not providing GUI based application

	5. This is a Command-Line application, yet too powerful.


	We sincerely request not to misuse the Application or any part of it, as we have worked hard to design it.


	For Any Queries or feedback, please don't hesitate to write to saisumanchitturi@gmail.com
